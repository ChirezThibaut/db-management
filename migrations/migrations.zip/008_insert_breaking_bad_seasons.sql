USE gebd;

INSERT INTO seasons
    (title, start_date, show_order, show_id)
    VALUES
    ('Season 1', '2008-01-20', 1, 1),
    ('Season 2', '2009-03-08', 2, 1),
    ('Season 3', '2010-03-21', 3, 1),
    ('Season 4', '2011-07-17', 4, 1),
    ('Season 5', '2012-07-15', 5, 1);