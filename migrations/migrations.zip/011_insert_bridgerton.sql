USE gebd;

INSERT INTO shows
    (title, start_date, status)
    VALUES
    ('Bridgerton', '2020-12-25', 'in progress');

SELECT id INTO @id FROM shows WHERE title = 'Bridgerton' LIMIT 1;

INSERT INTO seasons
    (title, start_date, show_order, show_id)
    VALUES
    ('Season 1', '2020-12-25', 1, @id);

SELECT id into @season_id FROM seasons WHERE show_id = @id ORDER BY show_order LIMIT 1;

INSERT INTO episodes
    (title, broadcast_date, season_order, show_order, season_id)
    VALUES
    ('Diamond of the First Water', '2020-12-25', 1, 1, @season_id),
    ('Shock and Delight', '2020-12-25', 2, 2, @season_id),
    ('Art of the Swoon', '2020-12-25', 3, 3, @season_id),
    ('An Affair of Honor', '2020-12-25', 4, 4, @season_id),
    ('The Duke and I', '2020-12-25', 5, 5, @season_id),
    ('Swish', '2020-12-25', 6, 6, @season_id),
    ('Oceans Apart', '2020-12-25', 7, 7, @season_id),
    ('After the Rain', '2020-12-25', 8, 8, @season_id);
