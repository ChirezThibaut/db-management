USE gebd;

ALTER TABLE episodes ADD COLUMN title varchar(255) AFTER id;