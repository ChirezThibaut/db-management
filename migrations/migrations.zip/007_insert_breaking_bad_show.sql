USE gebd;

INSERT INTO
    shows
    (title, start_date, end_date, status)
    VALUES
    ('Breaking Bad', '2008-01-20', '2013-09-29', 'ended');